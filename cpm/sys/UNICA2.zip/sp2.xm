; sp2.xm: part 2 of SPelling error detector Unicum
; /AJK 6.Sep.81, 6.Sep.81

;    _______
;   |      /
;   |     /
;   |    /    Copyright (c) 1981 by Knowlogy
;   |   //\                         PO Box 283
;   |  //  \                        Wilsonville, Oregon  97070
;   | //    \
;   |//______\

	uses LIB2800
	uses LIB2801

	db	'SP2 V1: COPYRIGHT (C) 1981 BY KNOWLOGY',13,10,26,0

MaxWord	equ	31		; maximum word length
BufSiz	equ	8192		; dictionary input buffer size

	entry sp2
sp2:
	HEAhea [hl=0100h]
	USKini []		; allow diversion of standard I/O

; Open the dictionary and allocate the word buffers.
sp21:
	BBIopn [stk=dname,stk=RO+Binary+OldOnly,stk=BufSiz]->[(dchn)=a]+C
	jp	c,error		; branch if no dictionary
	USKall [hl=MaxWord+1]->[(dword)=hl] ; allocate dictionary word buffer
	ld	(hl),0		; set dictionary word to empty
	USKall [hl=MaxWord+1]->[(iword)=hl] ; allocate input buffer

; Loop:
; Get a word from standard input.
; Find the first word from the dictionary which is greater than or equal
; to that word.
; If they're not equal, publish the standard input word.
sp22:
	LIOgl [stk=0,stk=(iword),stk=MaxWord+1]->[]+C
	jr	c,sp25		; branch if EOF on standard input
sp23:
	STRcmp [hl=(dword),de=(iword)]->[]+Z+C ; compare words
	jr	nc,sp24		; branch if dictionary word >= input word
	call	DRead		; read a new dictionary word
	jr	sp23		; try again
sp24:
	jr	z,sp22		; branch if words are equal, it's there
	LIOpl [stk=1,stk=(iword)] ; put the word to standard output
	jr	sp22		; loop for next word of input
sp25:				; here on EOF
	SHLexi [a=0]

; DRead: read a dictionary word.
DRead:
	ld	a,(deof)	; see if dictionary EOF has happened
	and	a
	ret	nz		; if so, return
	call	DBGet		; get length of next word in A
	cp	31		; check for EOF mark
	jr	z,dr3		; (branch if dictionary EOF)
	ld	ix,(dword)
	ld	c,a
	ld	b,0
	add	ix,bc		; IX -> first changed character in word
dr1:
	call	DBGet		; get next character of word
	and	a		; look for end-of-word
	jr	z,dr2
	add	a,'a'-1		; convert to alphabetic
	ld	(ix+0),a	; store into word being formed
	inc	ix
	jr	dr1
dr2:				; here at end-of-word
	ld	(ix+0),0	; null-terminate the word
	ret
dr3:				; here at dictionary EOF
	ld	a,1		; set EOF flag
	ld	(deof),a
	STRcpy [de=FFs,hl=(dword),bc=MaxWord+1] ; maximum possible word
	ret

; DBGet: get a five-bit dictionary byte
DBGet:
	push	bc		; save registers
	push	de
	push	hl
	ld	a,(byte)
	ld	e,a		; E = last byte read from dictionary
	ld	a,(lft)
	ld	d,a		; D = number of bits left in byte
	ld	c,0		; form return value (5-bit byte) in C
	ld	b,5		; B counts number of bits to get
dbg1:
	ld	a,d		; see if there are any bits left
	and	a
	jr	nz,dbg2		; branch if so
	BBIrea [stk=(dchn),stk=byte,stk=1]->[hl]+C-a ; read another byte
	jr	c,error		; error isn't allowed
	bit	0,l		; check that one byte was read
	ld	a,IoEOF		; (code for EOF error)
	jr	z,error		; EOF not allowed
	ld	a,(byte)	; get the byte we read
	ld	e,a
	ld	d,8		; reset bits left to 8
dbg2:				; here with good byte in E
	dec	d		; decrement number of bits left
	rl	e		; get a bit into carry
	rl	c		; rotate it into the byte we're forming
	djnz	dbg1		; loop for five bits
	ld	a,e		; store unused bits
	ld	(byte),a
	ld	a,d		; store count of bits left in byte
	ld	(lft),a
	ld	a,c		; return five-bit byte
	pop	hl
	pop	de
	pop	bc
	ret

error:
	ERRMSG [a=a,b=1,c=0,hl=dname]

; Data
dname:	db	'dict',0	; dictionary name	
byte:	db	0
lft:	db	0
dchn:	dw	0		; dictionary channel
deof:	db	0		; dictionary EOF flag
FFs:	rept	MaxWord
	db	0FFh
	endm
	db	0

dword:	ds	2		; -> dictionary word
iword:	ds	2		; -> word of input

	end sp2
