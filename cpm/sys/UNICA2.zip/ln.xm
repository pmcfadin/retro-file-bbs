; ln.xm: filename link forger
; /AJK 8.Jul.81, 18.Jul.81

;    _______
;   |      /
;   |     /
;   |    /    Copyright (c) 1981 by Knowlogy
;   |   //\                         PO Box 283
;   |  //  \                        Wilsonville, Oregon  97070
;   | //    \
;   |//______\

	uses LIB2800
	uses LIB2801

	db	'LN V1: COPYRIGHT (C) 1981 BY KNOWLOGY',13,10,26,0

	entry ln
ln:

; Initialize and scan command.
	HEAhea [hl=0100h]
	USKini []
	USKflg [hl=flgtbl]

; Loop for each file.
ln1:
	USKbnf [stk=(nflg),stk=(vflg),stk=1]->[hl=stk,bc=stk,de=stk,ix=stk]+C-a
	jr	c,ln2		; branch when no more files
	LINK [stk=hl,stk=ix,stk=(rflg)]->[a]+C
	jr	nc,ln1		; branch if no error
	ld	(code),a	; set return code
	EPUTF [stk="%t -> %t: ",stk=hl,stk=ix] ; extended error message
	ERRMSG [a=a,b=0,c=0,hl=hl]
	jr	ln1

; Here when done.
ln2:
	ld	a,(code)	; get return code
	SHLexi [a=a]

flgtbl:
	db 'n',0,0,0,0,0,0,0,0,0,0,0,0
nflg:	dw 0
	db 'r',0,0,0,0,0,0,0,0,0,0,0,0
rflg:	dw 0
	db 'v',0,0,0,0,0,0,0,0,0,0,0,0
vflg:	dw 0
	db 0

code:	db	0		; return code

	end ln
