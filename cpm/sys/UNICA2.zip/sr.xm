; sr.xm: pattern SeaRch unicum
; /AJK 15.Jun.81, 25.Aug.81

;    _______
;   |      /
;   |     /
;   |    /    Copyright (c) 1981 by Knowlogy
;   |   //\                         PO Box 283
;   |  //  \                        Wilsonville, Oregon  97070
;   | //    \
;   |//______\

	uses LIB2800		; Z80 components
	uses LIB2801		; CP/M components

	db	'SR V1: COPYRIGHT (C) 1981 BY KNOWLOGY',13,10,26,0

StdOut	equ	1		; standard output channel
LinLen	equ	256		; max input line length
BufSiz	equ	8192		; input buffer size

	entry sr
sr:
	HEAhea [hl=0100h]	; set up heap and stack
	USKini []		; initialize command scan
	USKflg [hl=flgtbl]	; interpret flags

; Prepare the pattern: surround it with asterisks so that the match
; can be anywhere in the line, instead of just the entire line.
	USKgna []->[hl]+C-a	; get the pattern argument
	jr	nc,sr1		; branch if argument supplied
	EPUTF [stk="Usage: sr [-acflnortvz] [-b begseq] [-e endseq] pattern [file ..]^m^j"]
	SHLexi [a=1]
sr1:
	push	hl		; save location of pattern
	STRlng [hl=hl]->[hl]	; obtain string length
	ld	de,3		; add one for each asterisk and one for null
	add	hl,de		; that's room we need for new string
	USKall [hl=hl]->[hl]	; allocate the pattern
	STRcpy [de="*",hl=hl,bc=0FFFFh] ; put in the first asterisk
	pop	de		; DE -> pattern argument
	STRcat [de=de,hl=hl,bc=bc] ; put in the pattern
	STRcat [de="*",hl=hl,bc=bc] ; finish off with second asterisk
	ld	(patrn),hl	; save pattern location

; If no files are specified, just read from standard input.
	USKdef [stk="-",stk=0]	; supply default arguments
	USKano []->[a]		; A = 2 if multiple files given
	ld	(mltflg),a	; save "multiple files" flag

; Clear the totals.
	ld	hl,0
	ld	(filtot),hl	; zero total file count
	ld	(mattot),hl	; zero total match count
	ld	(mattot+2),hl	; (mattot is a long)

; Allocate the line buffer.
	USKall [hl=LinLen]->[(line)=hl]

; If -a was specified, change the begin and end sequences.
	ld	a,(aflg)	; check for -a
	and	a
	jr	z,sr2		; branch if -a not specified
	ld	hl,altbeg	; change to alternate begin sequence
	ld	(begseq),hl
	ld	hl,altend	; and change to alternate end sequence
	ld	(endseq),hl

; Top of loop for each file.
sr2:
	USKtnf [stk=(nflg),stk=(vflg)]->[hl=stk,bc=stk,de=stk]+C-a
	jp	c,sr14		; branch when no more files
	BBIopn [stk=hl,stk=RO+Text+OldOnly,stk=BufSiz]->[a]+C
	jr	nc,sr3
	ERRMSG [a=a,b=1,c=0,hl=hl]
	jr	sr2		; skip this file
sr3:
	ld	(fname),hl	; store input file name
	ld	(inch),a	; save input channel
	xor	a		; mark that match hasn't occurred in this file
	ld	(matflg),a
	ld	h,a
	ld	l,a
	ld	(lineno),hl	; clear the current line number
	ld	(matcnt),hl	; clear the count of matches in this file

; Top of loop for each line.
sr4:
	BBIgl [stk=(inch),stk=(line),stk=LinLen]->[]+C-a
	jp	c,sr11		; branch when EOF
	ld	hl,(lineno)	; bump the current line number
	inc	hl
	ld	(lineno),hl
	MATmat [hl=(patrn),de=(line)]->[]+Z-a
	ld	a,(rflg)	; A = "-r" flag (reverse sense)
	jr	nz,sr5		; branch if pattern not in line
	and	a		; pattern is in line, see if -r specified
	jr	nz,sr4		; branch if so, ignore this line
	jr	sr6		; otherwise branch to announce this line
sr5:
	and	a		; pattern is not in line, see if -r
	jr	z,sr4		; branch if not, ignore this line

; Here to announce the line.
sr6:
	ld	hl,(matcnt)	; bump count of matches in this file
	inc	hl
	ld	(matcnt),hl

	ld	a,(matflg)
	ld	c,a		; C is the copy of matflg
	ld	a,1		; mark that this file has been highlighted
	ld	(matflg),a

; If -z was given, just bump the counts.
	ld	a,(zflg)	; see if -z is in effect
	and	a
	jr	nz,sr4		; if so, we have nothing to say yet

; If -f was given, just give the file name and bump the counts.  If -t is
;   not in effect, then we're not giving line counts so there's no point
;   in reading any longer, finish this file.
	ld	a,(fflg)	; see if -f is in effect
	and	a
	jr	z,sr8		; branch if not
	ld	a,c		; it is, see if filename has been given yet
	and	a
	jr	nz,sr7		; branch if so
	OPUTF [stk="%t^m^j",stk=(fname)] ; filename for -f
sr7:
	ld	a,(tflg)	; are we doing totals?
	and	a
	jp	z,sr13		; if not, we're done with this file
	jr	sr4		; otherwise just done with this line
sr8:

; If -c was given, just bump the file line count.
	ld	a,(cflg)	; see if -c is in effect
	and	a
	jr	nz,sr4		; if so, we're done with this line

; Otherwise if the file name has not been announced and -o is not in effect,
; do so.  Then, if -l is in effect, give the line number; then give the line.
	ld	a,c		; see if filename has been given yet
	and	a
	jr	nz,sr9		; branch if so
	ld	a,(mltflg)	; see if we should announce the file
	cp	2		; only if USKano returned 2
	jr	nz,sr9
	ld	a,(oflg)	; and if -o wasn't specified
	and	a
	jr	nz,sr9
	OPUTF [stk=(begseq)]	; print begin sequence
	OPUTF [stk="%t",stk=(fname)]
	OPUTF [stk=(endseq)]	; print end sequence
	OPUTF [stk="^m^j"]	; carriage return
sr9:
	ld	a,(lflg)	; -l?
	and	a
	jr	z,sr10		; branch if not
	OPUTF [stk="%5u:  ",stk=(lineno)] ; put line number
				; note that line number MUST consume 8 spaces,
				; else any tabs in the line will be messed up!
sr10:
	OPUTF [stk="%s^m^j",stk=(line)] ; put the line
	jp	sr4		; go read the next line

; Here when end-of-file.  If -c, give the line count.
sr11:
	ld	a,(cflg)	; see if -c
	and	a
	jr	z,sr12
	ld	a,(matflg)	; see if this file had a match
	and	a
	jr	z,sr12
	OPUTF [stk="%t: %mu lines^m^j",stk=(fname),stk=(matcnt)]
sr12:

; Transfer totals to grand totals.
	ld	a,(matflg)	; see if there were any matches
	and	a
	jr	z,sr13		; branch if none
	ld	hl,(filtot)	; bump file total
	inc	hl
	ld	(filtot),hl
	ld	hl,(mattot+2)	; bump matched line total
	ld	de,(matcnt)
	add	hl,de
	ld	(mattot+2),hl
	ld	hl,(mattot)
	ld	de,0
	adc	hl,de
	ld	(mattot),hl
sr13:

; Done with this file.
	BBIcls [stk=(inch)]
	jp	sr2		; go do another file

; Here when all files done.  Summarize.
sr14:
	ld	a,(tflg)	; see if -t or -z was specified
	and	a
	jr	nz,sr15
	ld	a,(zflg)
	and	a
	jr	z,sr16		; if not, don't give totals
sr15:
	OPUTF [stk="%mu files, %mlu lines^m^j",stk=(filtot),stk=(mattot),stk=(mattot+2)]
sr16:
	SHLexi [a=0]

; Flag table
flgtbl:
	db 'a',0,0,0,0,0,0,0,0,0,0,0,0
aflg:	dw 0
	db 'b',3,0,0,0,0,0,0,0,0,0
begseq:	dw pribeg,0
	db 'c',0,0,0,0,0,0,0,0,0,0,0,0
cflg:	dw 0
	db 'e',3,0,0,0,0,0,0,0,0,0
endseq:	dw priend,0
	db 'f',0,0,0,0,0,0,0,0,0,0,0,0
fflg:	dw 0
	db 'l',0,0,0,0,0,0,0,0,0,0,0,0
lflg:	dw 0
	db 'n',0,0,0,0,0,0,0,0,0,0,0,0
nflg:	dw 0
	db 'o',0,0,0,0,0,0,0,0,0,0,0,0
oflg:	dw 0
	db 'r',0,0,0,0,0,0,0,0,0,0,0,0
rflg:	dw 0
	db 't',0,0,0,0,0,0,0,0,0,0,0,0
tflg:	dw 0
	db 'v',0,0,0,0,0,0,0,0,0,0,0,0
vflg:	dw 0
	db 'z',0,0,0,0,0,0,0,0,0,0,0,0
zflg:	dw 0
	db 0

; Primary highlight begin/end sequences
pribeg:	db	'----- ',0
priend:	db	': -----',0

; Alternate highlight begin/end sequences.  These cause reverse video
; on a TRS-80 model II running Pickles&Trout CP/M.  If you have XM-80,
; you might want to change these to something appropriate for your
; terminal.
altbeg:	db	'^N',0
altend:	db	':^O',0

; Data
patrn:	ds	2		; -> pattern with asterisks appended
line:	ds	2		; -> line input buffer
fname:	ds	2		; -> this file name
inch:	ds	1		; current input channel
mltflg:	ds	1		; multiple files flag
matflg:	ds	1		; true if current file has a match
lineno:	ds	2		; line number within file
matcnt:	ds	2		; matches within file
filtot:	ds	2		; total matching files
mattot:	ds	4		; (long) total matching lines

	end sr
