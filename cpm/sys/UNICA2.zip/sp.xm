; sp.xm: SPelling error detector Unicum
; /AJK 6.Sep.81, 6.Sep.81

;    _______
;   |      /
;   |     /
;   |    /    Copyright (c) 1981 by Knowlogy
;   |   //\                         PO Box 283
;   |  //  \                        Wilsonville, Oregon  97070
;   | //    \
;   |//______\

	uses LIB2800
	uses LIB2801

	db	'SP V1: COPYRIGHT (C) 1981 BY KNOWLOGY',13,10,26,0

; Requires "sp2"

DEFDMA	equ	080h		; default DMA area
ComLen	equ	DEFDMA		; (byte) command length
ComStr	equ	DEFDMA+1	; (string) command
MaxCom	equ	128		; maximum command length

	entry spell		; label can't be "sp" (already a register name)
spell:
	HEAhea [hl=0100h]

; Call "wx" to extract the word list; then call "srt" to sort it and
; remove duplicate entries; then call "sp" again.

; Examine the arguments and form a command of the form

;   wx args | srt -u | sp >stdoutput

; where the ">stdoutput" is any argument which diverts standard output
; (starts with "|" or ">") and the other arguments are given to "wx".
; "^" is a magic character which tells us this is the second invocation.

; Null-terminate the command string.
	ld	a,(ComLen)
	ld	c,a
	ld	b,0		; BC = length of command
	ld	hl,ComStr
	add	hl,bc
	ld	(hl),0

; Find the first ">" or "|" in the command; assume that the remainder
; of the command string is standard output diversion.
	ld	hl,ComStr
sp1:
	ld	a,(hl)		; A = next character
	and	a		; check for null terminator
	jr	z,sp2
	cp	'>'		; check for ">"
	jr	z,sp2
	cp	'|'		; check for "|"
	jr	z,sp2
	inc	hl		; none of those, skip this character
	jr	sp1		; loop
sp2:				; here with HL -> second half of command
	ld	bc,MaxCom	; BC = maximum command length
	ex	de,hl		; DE -> second half of command
	STRcpy [de=de,hl=half2,bc] ; copy second half of command
	xor	a
	ld	(de),a		; null-terminate first half
	STRcpy [de=ComStr,hl=half1,bc] ; copy first half of command
	ex	de,hl		; HL -> command string

; Now prepare the command.
	STRcpy [de=half1,hl,bc]	; arguments to "wx"
	STRcat [de="|srt -u|sp2 ",hl,bc]
	STRcat [de=half2,hl,bc]
	STRlng [hl]->[hl]	; HL = command length
	ld	a,l
	ld	(ComLen),a

; Command is in place, execute "wx".
	EXEC [hl="wx"]->[a]+C
	IOERR [a=a,b=1,c=1,hl=hl]

half1:	ds	MaxCom		; first half of arguments
half2:	ds	MaxCom		; second half of arguments

	end spell
