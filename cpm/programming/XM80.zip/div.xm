; div.xm: 16 / 16 -> 16 unsigned divide

	provides DIV

	proc DIV [DIVISOR:de,DIVIDEND:hl]->[QUOTIENT:hl]
	begin
	push	af		; save registers
	push	bc
	push	de
; Check for zerodivide condition
	ld	a,d		; check for zero divisor
	or	e
	jr	nz,div1		; branch if not
	ld	hl,0FFFFh	; supply "machine infinity" as result
	jr	div6
; Maintain quotient at (SP)
div1:
	ld	bc,0		; clear quotient
	push	bc		; (SP) contains quotient
	inc	bc		; BC = 1: walking power of 2
; Left-justify the divisor
div2:
	bit	7,d		; see if DE is left-justified
	jr	nz,div3		; branch if it is
	sla	e		; shift DE left one bit
	rl	d
	sla	c		; multiply BC by 2
	rl	b
	jr	div2		; loop until left-justified
; Loop until BC becomes zero.
; Try subtracting.
div3:
	and	a		; (clear carry for subtract)
	sbc	hl,de		; subtract
	jr	c,div4		; branch if overflow
	ex	(sp),hl		; get quotient into HL
	add	hl,bc		; add this power of 2
	ex	(sp),hl
	jr	div5
div4:				; here if overflow
	add	hl,de		; restore HL
div5:
	srl	b		; shift BC right one bit
	rr	c
	srl	d		; shift DE right one bit
	rr	e
	ld	a,b		; check for BC zero
	or	c
	jr	nz,div3
	pop	hl		; quotient to HL
div6:
	pop	de		; restore registers
	pop	bc
	pop	af
	end DIV
