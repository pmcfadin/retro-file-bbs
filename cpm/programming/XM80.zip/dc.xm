; dc: a "Desk Calculator"

	uses LIB2800		; 2800 family
	uses LIB2801		; 2801 family

	uses MUL		; 16 by 16 multiplication
	uses DIV		; 16 into 16 division

dc:
	HEAhea [hl=0100h]	; initialize stack and heap
	USKini []		; scan command: allow diversion

; Top of loop to do a line.
; Read a line from standard input.
dc1:
	LIOgl [stk=0,stk=line,stk=256]->[]+C
	jp	c,dc9		; exit on input EOF
	ld	hl,line		; set line pointer to beginning
	ld	(lptr),hl

; Top of loop to get an atom, which is either a numeral or
; an operation.
dc2:
	ld	hl,(lptr)	; HL is pointer within line
dc3:
	ld	a,(hl)		; A = next character
	and	a		; check for null (end-of-line)
	jp	z,dc8		; branch when line exhausted
	cp	' '		; skip over spaces
	jp	nz,dc4
	inc	hl		; found a space, ignore it
	jp	dc3
dc4:				; here with non-null non-space

; See if the atom is a number.  Try to interpret it using
; the current radix.
	ld	a,(radix)	; radix is 0 for decimal
	and	a		;   or 1 for hexadecimal
	jp	nz,dc5		; branch to use hex
	ATOI [hl]->[hl,de]+C	; try to get decimal numeral
	jp	nc,dc6		; branch if successful
	jp	dc7		; branch if not
dc5:				; here to use hex
	ATOH [hl]->[hl,de]+C	; try to get hexadecimal
	jp	c,dc7		; branch if not successful
dc6:
	call	push		; push the stack
	ld	(stk.x),de	; put the number in "X" register
	jp	dc3		; go interpret another atom

; Here if the atom isn't a number.  Treat is as a one-character
; operator.
dc7:
	ld	a,(hl)		; A = operator character
	inc	hl		; advance HL past this character
	ld	(lptr),hl	; store current line pointer

; Preload the "Y" register into HL and the "X" register into DE.
	ld	hl,(stk.y)
	ld	de,(stk.x)

; Investigate the operator, and dispatch to its handler.
	cp	'+'		; addition
	jp	z,op.add
	cp	'-'		; subtraction
	jp	z,op.sub
	cp	'*'		; multiplication
	jp	z,op.mul
	cp	'/'		; division
	jp	z,op.div
	cp	'^'		; negate (twos complement)
	jp	z,op.neg
	cp	'~'		; binary NOT
	jp	z,op.not
	cp	'&'		; binary AND
	jp	z,op.and
	cp	'|'		; binary OR
	jp	z,op.or
	cp	'#'		; binary XOR
	jp	z,op.xor
	cp	'$'		; change radix
	jp	z,op.rad
	cp	'>'		; store memory
	jp	z,op.sto
	cp	'<'		; recall memory
	jp	z,op.rcl
	cp	'?'		; dump stack and memory
	jp	z,op.dmp
	cp	'!'		; clear stack and memory
	jp	z,op.clr

; If it's not a known operator, error message
	OPUTF [stk="unknown operator '%pc'^m^j",stk=af]
	jp	dc2

; Operation dispatch routines.
op.add:				; addition
	add	hl,de
	jp	popngo
op.sub:				; subtraction
	and	a		; clear carry for subtract
	sbc	hl,de
	jp	popngo
op.mul:				; multiplication
	MUL [hl,de]->[hl]
	jp	popngo
op.div:				; division
	DIV [hl,de]->[hl]
	jp	popngo
op.neg:				; negation
	ld	hl,0		; compute 0-X
	and	a		; clear carry for subtract
	sbc	hl,de		; HL gets -X
	jp	strngo
op.not:				; logical complement
	ld	a,d
	cpl
	ld	h,a
	ld	a,e
	cpl
	ld	l,a
	jp	strngo
op.and:				; logical AND
	ld	a,h
	and	d
	ld	h,a
	ld	a,l
	and	e
	ld	l,a
	jp	popngo
op.or:				; logical OR
	ld	a,h
	or	d
	ld	h,a
	ld	a,l
	or	e
	ld	l,a
	jp	popngo
op.xor:				; exclusive-OR
	ld	a,h
	xor	d
	ld	h,a
	ld	a,l
	xor	e
	ld	l,a
	jp	popngo
op.rad:				; change radix
	ld	a,(radix)	; A is current radix, 0 or 1
	xor	1		; toggle low bit
	and	1		; turn off all other bits
	ld	(radix),a
	jp	go
op.sto:				; store to memory
	ld	(mem),de
	jp	go
op.rcl:				; recall memory
	call	push		; push the stack
	ld	hl,(mem)
	ld	(stk.x),hl
	jp	go
op.dmp:				; dump stack and memory
	ld	hl,(stk.x)
	OPUTF [stk="x: %5u  %a^m^j",stk=hl,stk=hl]
	ld	hl,(stk.y)
	OPUTF [stk="y: %5u  %a^m^j",stk=hl,stk=hl]
	ld	hl,(stk.z)
	OPUTF [stk="z: %5u  %a^m^j",stk=hl,stk=hl]
	ld	hl,(stk.t)
	OPUTF [stk="t: %5u  %a^m^j",stk=hl,stk=hl]
	ld	hl,(mem)
	OPUTF [stk="m: %5u  %a^m^j",stk=hl,stk=hl]
	jp	go
op.clr:				; clear stack and memory
	ld	hl,0
	ld	(stk.x),hl
	ld	(stk.y),hl
	ld	(stk.z),hl
	ld	(stk.t),hl
	ld	(mem),hl
	jp	go

; Here to pop the stack and store HL at stk.x
popngo:
	ld	de,(stk.y)
	ld	(stk.x),de
	ld	de,(stk.z)
	ld	(stk.y),de
	ld	de,(stk.t)
	ld	(stk.z),de

; Here to store HL at stk.x
strngo:
	ld	(stk.x),hl

; Here when done with operation
go:
	jp	dc2		; go do another atom

; Here when done with a line.
; Print the X register as signed and unsigned decimal, and hex.
dc8:
	ld	hl,(stk.x)
	OPUTF [stk="   %5u  %a^m^j",stk=hl,stk=hl]
	jp	dc1		; go do another line

; Here on input EOF.
dc9:
	SHLexi [a=0]

; Push routine: copy X->Y, Y->Z, Z->T
push:
	push	hl		; save HL
	ld	hl,(stk.z)
	ld	(stk.t),hl
	ld	hl,(stk.y)
	ld	(stk.z),hl
	ld	hl,(stk.x)
	ld	(stk.y),hl
	pop	hl
	ret

; Data.
stk.x:	dw	0		; X register
stk.y:	dw	0		; Y register
stk.z:	dw	0		; Z register
stk.t:	dw	0		; T register
mem:	dw	0		; memory register
radix:	db	0		; radix: 0 for dec, 1 for hex

lptr:	ds	2		; pointer within input line
line:	ds	256		; input line

	end dc
