monstrates converting back and 
                    forth between calendar date and julian date.
     DATETEST.HEX    --fast assembly-language date checking routine which is 
                    called by several of the example programs.
     



 