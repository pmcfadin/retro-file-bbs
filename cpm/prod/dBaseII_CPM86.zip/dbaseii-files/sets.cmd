               ? NAME
                         ? PHONE
                         SKIP
                       ENDDO  
*CASE



> DO CASE  -- used in command file to choose one and only one of several 
       possible execution paths.  OTHERWISE clause optional, and executes 
       when no CASE is true. ENDCASE is needed to close command.
    
 e.g.     USE MAILLIST
          ACCEPT "WHICH MENU OPTION DO YOU PREFER?" to CHOICE
          DO CASE                           
                CASE Ch