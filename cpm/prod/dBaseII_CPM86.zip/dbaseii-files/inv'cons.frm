l but are useful as described below:

*UTILITIES       
UTILITY FILES TO WORK WITH YOUR dBASE II SYSTEM:

     STARTUP.CMD    --this command file is intended to help you determine if 
                    your terminal is properly installed.  Type DO 