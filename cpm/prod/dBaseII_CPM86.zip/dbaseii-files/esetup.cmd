 ON       -- eliminates extra spaces in DISPLAY and ? commands.
       UPDATE           -- replace clause can have WITH phrases.
*EXIT
*?
*??
> ?    -- Evaluates  and displays the value of an  expression.   In  command 
       file  (and elsewhere) can be used without expression to space down  a 
       line at output.
      
          . ? 6/3
            2
          . ? 'CITY'
            CITY
          . ? CITY (field of file in use)
            Managua
 
> ??   -- Same as ?, but displays result on same line as entry.
*EXIT
*@
> @    -- Displays user formatted data on the screen or printer at specified 
          x,y coordinates (x = line, y = column ).

          Syntax: @ <coords> [SAY <exp> [USING '<picture>']]
                             [GET <variable> [PICTURE '<picture>']]

          @  3,23 SAY AMOUNT * 1.06 USING '$$$,$$$.99'
          @ 14,23 SAY "ENTER PHONE" GET PHONE PICTURE '(###)###-####'
          @ LINE+2,45 SAY TOTAL USING '99999.99'
*EXIT
*ACCEPT
>  ACCEPT  